// postMessageBridge.js
window.addEventListener('DOMContentLoaded', () => {
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach(iframe => {
    // Escucha mensajes del iframe
    window.addEventListener('message', (event) => {
      if (event.source === iframe.contentWindow) {
        // Ejemplo: recibe tamaño y ajusta el iframe
        if (event.data && event.data.type === 'resize') {
          iframe.style.height = event.data.height + 'px';
        }
        // Reenvía eventos a la shell si es necesario
      }
    });
    // Envía mensaje de usuario de ejemplo
    iframe.addEventListener('load', () => {
      iframe.contentWindow.postMessage({ user: 'Juan Pérez' }, '*');
    });
    // Observa cambios de tamaño en el iframe
    const resizeObserver = new ResizeObserver(() => {
      iframe.contentWindow.postMessage({ type: 'requestResize' }, '*');
    });
    resizeObserver.observe(iframe);
  });
}); 